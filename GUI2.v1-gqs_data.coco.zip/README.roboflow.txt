
GUI2 - v1 GQS_data
==============================

This dataset was exported via roboflow.ai on March 15, 2022 at 5:24 PM GMT

It includes 364 images.
Interface-components are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


