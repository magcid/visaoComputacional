
GUI_Components - v2 2022-03-14 2:10pm
==============================

This dataset was exported via roboflow.ai on March 14, 2022 at 5:11 PM GMT

It includes 290 images.
Gui are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


